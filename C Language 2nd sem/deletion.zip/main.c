#include<stdio.h>
void main(){
    int a[10];
    int k,i,n,pos;
    
    clrscr ();
    
}












