int main()
{
    #undef BIRD
    printf("OKAY");
    return 0;
}