// Write a progrma to read an array, print an array using function



#include <stdio.h>



#define SIZE 5
void read(int n[],int size); //protoptye
void print(int n[],int size);
void increment(int [],int);



void main()
{
int a[SIZE];

read(a,SIZE);
print(a,SIZE);
increment(a,SIZE);
print(a,SIZE);

}




void read(int n[], int size_t)
{
int i;

for(i=0;i<size_t;i++)
{
puts("\n Enter the element :");
scanf("%d",&n[i]);
}
}



void print(int p[], int size_t)
{
int i;

for(i=0;i<size_t;i++)
{
printf("\t %d", p[i]);
}
}
void increment(int p[], int size_t)
{
int i;

for(i=0;i<size_t;i++)
{
p[i]++;
}
}