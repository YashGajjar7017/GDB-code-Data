#include<stdio.h>
#include<conio.h>

int main()
{
    int i,j;
    
    puts("Enter your number : ");
    for(i=0;i<10;i++)
    {
        scanf("%d",&i);
    }
    
    for(j=0;j<10;j++)
    {
        printf("Your answer is :%d\t",i);
    }
    printf("%d",i);
    
    
}