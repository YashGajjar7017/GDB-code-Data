#include<stdio.h>
#define SIZE 5
void main()
{

int i;
int a[SIZE], b[SIZE] ;

for(i=0;i<SIZE;i++)
{
printf("\n Enter the marks of %d subject",i+1);
scanf("%d",&a[i]);
b[i]=a[i];
}

for(i=0;i<SIZE;i++)
{
printf("\na[%d]= %d b[%d]=%d ",i,a[i],i,b[i]);
}

return 0;
}