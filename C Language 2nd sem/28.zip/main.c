#include <stdio.h>
    struct student
    {
    };
    void main()
    {
        struct student s[2];
        printf("%d", sizeof(s));
    }