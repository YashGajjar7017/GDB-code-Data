
#include <stdio.h>
#define SIZE 5
int main()
{
int i;
int a[SIZE], b[SIZE] ;
for(i=0;i<SIZE;i++)
{
printf("\n Enter the marks of %d subject",i+1);
scanf("%d",&a[i]);
}
for(i=0;i<SIZE;i++)
{
b[i]=a[i];
}
for(i=0;i<SIZE;i++)
{
printf("\t %d",a[i]);
}
for(i=0;i<SIZE;i++)
{
printf("\t %d",b[i]);
} 
return 0;
}
 

