#include <stdio.h>
    struct test
    {
        int k;
        char c;
    };