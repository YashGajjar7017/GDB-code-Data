#include<stdio.h>
// #include<process.h>
void main ()
{
  int magic[3][3], i, j, psum, sum;

  puts ("Enter 3x3 matrix row-wise");
  for (i = 0; i < 3; i++)
    {
      for (j = 0; j < 3; j++)
	{
	  scanf ("%d", &magic[i][j]);
	}
    }


  // sum the principle diagonal
  psum = 0;
  for (i = 0; j = 0; i = 3 && j < 3; i++; j++)
    {
      psum += magic[i][j];
    }


  // sum the second diagonal
  sum = 0;
  for (i = 0; j = 2; i < 3 && j >= 0; i++; j--)
    {
      sum += magic[i][j];
    }


  // compare psum ans sum
  if (psum != sum)
    {
      printf ("not a magic square \n");
      exit (0);
    }


  // sum the rows one by one and compare sum

  for (i = 0; i < 3; i++)
    {
      sum = 0;
      // sum the ith row 
      for (j = 0; j < 3; j++)
	{
	  sum += magic[i][j];
	}
      // compare sum with psum
      if (psum != sum)
	{
	  printf ("Not a magic square \n");
	  exit (0);
	}

    }
//  sum the column one by one and compare sum
  for (i = 0; i < 3; i++)
    {
      sum = 0;
      //  sum the jth column
      for (j = 0; j < 3; j++)
	{
	  sum += magic[i][j];
	  // compare sum with psum
	  if (psum != sum)
	    {
	      printf ("not a magic square \n");
	      exit (0);
	    }
	}

      // All sums are equal 
      printf ("magic square");
 }

