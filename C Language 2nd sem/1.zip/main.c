#define BIRD 5
int main()
{
    #ifdef BIRD
        printf("BIRD=5.");
    #else
        printf("UNKNOWN.");
    #endif
    #undef BIRD
    #define BIRD 10
    printf("BIRD=%d",BIRD);
    return 0;
}