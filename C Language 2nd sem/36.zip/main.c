#include <stdio.h>
    struct student
    {
        char *c;
        struct student *point;
    };
    void main()
    {
        struct student s;
        struct student m;
        s.c = m.c = "hi";
        m.point = &s;
        (m.point)->c = "hey";
        printf("%s\t%s\t", s.c, m.c);
    }