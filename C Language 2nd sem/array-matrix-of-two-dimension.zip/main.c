#include<stdio.h>

void main()
{
    int a[3][3],b[3][3],c[3][3],i,j;
    
    puts("Enter the value of matrix A ");
    for(i=0;i<3;i++)
    {
        for(j=0;j<3;j++)
        {
            scanf("%d",&a[i][j]);
        }
    }
    
    puts("Enter the value of matrix B ");
    for(i=0;i<3;i++)
    {
        for(j=0;j<3;j++)
        {
            scanf("%d",&a[i][j]);
        }
    }
    
    puts("sum of two matrix :");
    for(i=0;i<3;i++)
    {
        for(j=0;j<3;j++)
        {
            printf("%d",c[i][j]);
            printf("\n");
        }
    }
}

    
    