#include<stdio.h>
// #include<conio.h>

void main()
{
    int a[10];
    int k,i,n,val,pos;
    
    printf("Enter size of the array: \n");
    scanf("%d",&n);
    printf("Enter the elements :");
    
    for(i=0;i<n;i++)
    {
        scanf("%d",a[i]);
    }
     
     printf("Enter the position to insert");
     scanf("%d",&pos);
     
     printf("Enter value:");
     scanf("%d",&val);
     
     for(k=n-1;k>=pos;k--)
      {
        a[k+1]=a[k];
        a[pos]=val;
        n=n+1;
        
        printf("Array after insertion :");
        for(i=0;i<n;i++)
        {
            printf("%d",a[i]);
        }
        printf("/n");
      }
        
        
}
