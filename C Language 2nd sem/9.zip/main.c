#define CVV 156
int main()
{
    int a=10;
    a = a*CVV;
    printf("CVV=%d",a);
    return 0;
}