#include<stdio.h>
#define hello 
main()
{
    #ifdef hello
    #define hi 4
    #else
    #define hi 5
    #endif
    printf("%d",hi);
 
}