#include <stdio.h>
    struct student
    {
        int no;
        char name[20];
    };
    void main()
    {
        student s;
        s.no = 8;
        printf("hello");
    }