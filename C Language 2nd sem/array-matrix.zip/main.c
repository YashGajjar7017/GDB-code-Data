#include <stdio.h>
#define R 2
#define C 3



int main()
{



// datatype arrayname[rows][columns];
int a[R][C],i,j;

// 1 --> 1 2 3
//2 ---> 1 2 3

// 0 ---> 0 1 2 00 01 02
//1 --> 0 1 2 10 11 12

for(i=0;i<R;i++)
{
for(j=0;j<C;j++)
{
printf("Enter data");
scanf("%d",&a[i][j]);
}
}

for(i=0;i<R;i++)
{
for(j=0;j<C;j++)
{

printf("%d\t",a[i][j]);
}

printf("\n");
}



}