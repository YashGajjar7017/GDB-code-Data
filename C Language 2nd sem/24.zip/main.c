#include <stdio.h>
    struct point
    {
        int x;
        int y;
    };
    int main()
    {
        struct point p = {1};
        struct point p1 = {1};
        if(p == p1)
            printf("equal\n");
        else
            printf("not equal\n");
    }