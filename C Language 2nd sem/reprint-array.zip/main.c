
#include <stdio.h>
#define SIZE 5
int main()
    
     {
//merging two arrays and size of each array is same, creating new array out of two arrays
       int i;
       int a[SIZE], b[SIZE], c[SIZE * 2];
//Read array a
       for (i = 0; i < SIZE; i++)
	 {
	   printf ("\n ARRAY A Enter the marks of %d subject", i + 1);
	   scanf ("%d", &a[i]);
	 }
//Read array b
       for (i = 0; i < SIZE; i++)
	 {
	   printf ("\n ARRAY B the marks of %d subject", i + 1);
	   scanf ("%d", &b[i]);
	 }
//printing array A
       for (i = 0; i < SIZE; i++)
	 {
	   printf ("\n a[%d]=%d b[%d]=%d", i, a[i], i, b[i]);
	 }
       printf ("\n");
// copy array a and b to array c
       for (i = 0; i < SIZE; i++)
	 {
	   c[i] = a[i];
	   c[SIZE + i] = b[i];
	 }
//print array c
       for (i = 0; i < SIZE * 2; i++)
	 {
	   printf (" %d", c[i]);
	 }
       return 0;
     }
