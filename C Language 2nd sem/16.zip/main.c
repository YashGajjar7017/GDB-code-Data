#define CVV 156
int main()
{
    #ifdef CVV
        printf("CVV YES");
    #else
        printf("CVV NO");
    #endif
    return 0;
}