#include <stdio.h>
    struct student
    {
        char *c;
    };
    void main()
    {
        struct student n;
        struct student *s = &n;
        (*s).c = "hello";
        printf("%p\n%p\n", s, &n);
    }