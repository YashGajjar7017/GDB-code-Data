int main()
{
    #ifndef CVV
        #define CVV 199
        printf("CVV=%d", CVV);
    #else
        printf("CVV=%d", 188);
    #endif
    return 0;
}