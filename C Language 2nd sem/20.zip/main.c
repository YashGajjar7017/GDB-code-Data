int main()
{
    #ifdef CVV
        #define CVV 199
    #elif PVV
        printf("Inside ELIF");
    #else
        printf("Inside ELSE");
    #endif
    return 0;
}