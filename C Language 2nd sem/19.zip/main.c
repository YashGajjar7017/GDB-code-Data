void show();
int main()
{
    #ifndef CVV
        #define CVV 199
    #endif
    show();
    return 0;
}
void show()
{
    printf("CVV=%d",CVV);
}