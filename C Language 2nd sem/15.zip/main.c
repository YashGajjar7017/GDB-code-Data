#define TANK(a) a*10+2
int main()
{
    int a = TANK(2)*2;
    printf("%d",a);
    return 0;
}