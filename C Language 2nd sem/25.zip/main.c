#include <stdio.h>
    struct point
    {
        int x;
        int y;
    };
    struct notpoint
    {
        int x;
        int y;
    };
    int main()
    {
        struct point p = {1};
        struct notpoint p1 = p;
        printf("%d\n", p1.x);
    }