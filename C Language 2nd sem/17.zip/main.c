int main()
{
    #ifdef CVV
        printf("CVV YES");
    #else
        #define CVV 199
    #endif
    printf("NEW CVV=%d",CVV);
    return 0;
}