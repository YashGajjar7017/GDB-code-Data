#include <stdio.h>
#define SIZE1 5
#define SIZE2 6
int main()
{
//merging two arrays and size of each array is different, creating new array out of two arrays
int i;
int a[SIZE1], b[SIZE2] , c[SIZE1+ SIZE2];

//Read array a
for(i=0;i<SIZE1;i++)
{
printf("\n ARRAY A Enter the marks of %d subject",i+1);
scanf("%d",&a[i]);

}
//Read array b
for(i=0;i<SIZE2;i++)
{
printf("\n ARRAY B the marks of %d subject",i+1);
scanf("%d",&b[i]);
}
//printing array A
for(i=0;i<SIZE1;i++)
{
printf("\t%d",a[i] );
}
printf("\n");
//printing of array B
for(i=0;i<SIZE2;i++)
{
printf("\t%d",b[i] );
}
printf("\n");

// copy array a to array c
for(i=0;i<SIZE1;i++)
{
c[i]= a[i];
}
//copy array b to array c
for(i=0;i<SIZE2;i++)
{
c[SIZE1+i]= b[i];
}
//print array c
for(i=0;i<SIZE1+SIZE2;i++)
{
printf(" %d",c[i] );
}
return 0;
}