#include<stdio.h>
#define max 100
main()
{
    #ifdef max
    printf("hello");
}