#include<stdio.h>
#pragma GCC poison printf
main()
{
    printf("sanfoundry");
    return 0;
}