#define ERRMSG printf("Some error.");
int main()
{
    printf("JAR.");
    ERRMSG;
    return 0;
}