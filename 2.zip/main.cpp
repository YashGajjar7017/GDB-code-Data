#include<iostream>
using namespace std;
struct student 
{
	int rollno;
	char name[5];
};

int main()
{
	struct student s;
	s.rollno=10;
// 	s.name="yash";
	cout<<"/rollno"<<s.rollno;
	cout<<"/name"<<s.name;
	
	
}