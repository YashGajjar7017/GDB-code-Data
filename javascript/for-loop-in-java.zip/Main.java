
public class Main
{
	public static void main(String[] args) {
// 		System.out.println("Hello World");
        int a;
        
        for(a=0;a<50;a++)
        {
            if(a==35){
                break;
            }
            else{
               System.out.println(a); 
            }
            System.out.println(a);
        }
        
        
        //for each
        
        int b;
        for(int b:)
        {
            System.out.println();
        }
            
        
        
        
	}
}
