
public class Main
{
	public static void main(String[] args) {
// 		System.out.println("Hello World");
		
		String[]cars={"yash1","yash2","yash3","yash4","yash5","yash6"};
		
		try {
		     System.out.println(cars[6]); //there is error in this line ,so how to buy pass it. 
		} 
		catch(Exception e) 
		{
		    System.out.println(e);
		}
		
		
		System.out.println("who often you");
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
