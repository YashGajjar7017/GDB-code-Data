public class Main {
public static void main (String[] args) {

//java is case sensitive
int a=6*5-34/2;
System.out.println(a);

int b=34/2-6*5;
System.out.println(b);

// precedence and Associativity

int x=a*b/2*y;
System.out.println(x);
// parenthises means ()and []

   }    
}