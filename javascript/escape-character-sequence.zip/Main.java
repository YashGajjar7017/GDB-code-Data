
public class Main
{
	public static void main(String[] args) {
// 		System.out.println("Hello World");

    String name = "yash";
    String channel="CID";
    
    // this is method to ckeck how many letter are there in String
    System.out.println(name.length());
    
    //this method is to print all small letter into big letter
    System.out.println(name.toUpperCase());

    // this method is same from above
    System.out.println(name.toLowerCase());
    
    // print sign in and after or between the words
    
    System.out.println(name+"with\""+ channel);
    System.out.println(name+"with\\"+ channel);
    System.out.println(name+"with\t"+ channel);
    System.out.println(name+"with\n"+ channel);
    System.out.println(name+"with\r"+ channel);
    
    
    // This method is to find any words in the letter without ckecking it 
     System.out.println(name.contains("sh"));
     
    // this one is to ckeckwords at index level 
     System.out.println(name.charAt(0));
    
    // this one to ckeck the word ends with ?
      System.out.println(name.endsWith("s"));

    // (-1 means false) This is for to print you lettes's first index 
    System.out.println(name.indexOf("ya"));







	}
}

