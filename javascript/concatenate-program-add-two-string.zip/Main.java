
public class Main
{
	public static void main(String[] args) {
// 		System.out.println("Hello World");
		
		String name ="yash";
		String channel ="CID";
// 		System.out.println(name);
		System.out.println(name+ " from "+ channel);
	}
}
