
public class Main
{
	public static void main(String[] args) {
// 	If ladder

        int age=21;
        
        if(age<5)
        {
            System.out.println("you are not a kid");
        }
        else if(age>20)
        {
            System.out.println("Your are adult now");
        }
        else
        {
            System.out.println("you are kid");
        }
	}
}
