public class Main{
     public static void main (String[] args) {
    
    int i=20;
    System.out.println(i++);
    System.out.println(i);
    System.out.println(++i);
    System.out.println(i);
    
    int y=45;
    byte a=20;
    float c=y+a;
    System.out.println(c);
     
    // another method 
    int b=30;
    System.out.println(++b/2);
    
    // one more method
    char z='a';
    System.out.println(++z);
    
   }
}