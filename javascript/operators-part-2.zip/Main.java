import java.util.*;

 class UserInputDemo1

{
	public static void main(String[] args) {
// 		System.out.println("Hello yash");
		
		/*
		 Comparison operators:
		 1) ==  (Ckeck for equality of two variables )
		 2) !=  (Ckeck if two values are equal or not)
		 3) <   (ckeck if number is on left side is less then )
		 4) >   ()
		 5) <=
		 6) >=
		
		logical operators;
		1)&& --> logical and operators [returns true only if both conditions are true]
		2)|| --> logical or operators [returns true if any one condition is true ]
		3)!  --> logical not operators [reverse the result from true to false and vice versa ]
		
		*/
		
		// scan from user :
		
		 scanner sc = new scanner(System.in);
		 System.out.println("Enter input:");
		 string str =sc.nextline();
// 		 System.out.println(input);
		
		
		
		
		
		
		
	}
}
