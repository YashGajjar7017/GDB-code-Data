
public class Main
{
	public static void main(String[] args) {
// 		System.out.println("Hello World");
		
		int num1=2,num2=4;
		//This print's the highest value among this number 
		System.out.println(Math.max(4,7));
		
		//This shows the lowest
		System.out.println(Math.min(num1,num2));
		
		//*This shows the square root of any number 
		System.out.println(Math.sqrt(81));
		
		//This is for any negative number convert into positive
		System.out.println(Math.abs(-200));
		
		//same
		System.out.println(Math.abs(200));
		
		//random:This print any garbage value 
		System.out.println(Math.random());
		
		//This gives random number from our data
		System.out.println((10+15)*Math.random());
		
		
		
		
		
	}
}
