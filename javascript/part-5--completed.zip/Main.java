// package company.company;
// import java.util.Scanner;

// public class caty
// {
// 	public static void main(String[] args) {
// 		System.out.println("I am yash");
		
// 		Scanner sc = new Scanner(System.in);
// 		System.out.println(sc);
// 		System.out.println("Enter first number");
// 		System.out.println("first number");
//  		int a = sc.nextInt();
// 		float a = sc.nextFloat();
// 		System.out.println("second number");
// 		int b= sc.nextInt();
// 		Float sum = a+b;
// 		System.out.println("The sum of this two number is");
// 		System.out.println(sum);


	
// 		boolean b1 = sc.hasNextBoolean();
// 		System.out.println(b1);
		
		
// 		String bhk = sc.next();
// 		String str = sc.nextLine();
// 		System.out.println(str);
		
// 	}
// }



// public class HelloWorld {
//     public static void main(String[] args) {
//         // Write your code here
//         System.out.println("My name is yash");
//     }
// }


class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World!"); 
    }
}









