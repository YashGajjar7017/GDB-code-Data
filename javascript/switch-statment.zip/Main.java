
public class Main
{
	public static void main(String[] args) {
// 		System.out.println("Hello World");
        int a=18;
        
        switch(a)
        {
            case 12:
                System.out.println("Your are a child");
                break;
            
            case 18:
                System.out.println("You are now a youngester");
                break;
                
            case 23:
                System.out.println("You are now an adult");
                break;
            
            default:
                System.out.println("you are nothing");
        }
    
	}
}
