
public class Main     //class means like blueprint or templet 
{
	public static void main(String[] args) {  // [public=all can asscess ;static=means they only (class main);
	//void =meansthis program does not return any value ;main= program is start from here ]
		System.out.println("1)My name is yash");
		
		/* 1)variables are containers which store data values:
		     string,char,float,int,boolean
		 
		   2)how to declare variables:
		   syntax= <datatype> <variablesname> =<value>;
		 
		*/
		String name="yash";
		System.out.println( name);
		
		int a=45,c=20;
		System.out.println(a);
		
		float b=23.89f;
		System.out.println(b);
	    
	    boolean car=true;
	    System.out.println(car);
	    
	    /* Rules for constructing name of variables in java:
	        --> can contain digits, underscroces,dollar sign,letters
	        --> should begin with a letters, $ or _ .
	        --> java is case censitive language ,
	            which means that harry and Harry are two different variables altogether .
	        --> Should not contain whitespaces
	        --> you cannot use reserved keywords from java
	        
	        
	        
	        two types of java data types :
	        1) primitive  -->byte (1 byte),short (2 byte),int (4 byte),long (8 byte),float (4 byte),double (8 byte)
	                         boolean (1 byte), char(2 byte).
	        
	        2) non primitive or reference data type
	        */
	        
	        byte y=127;    // the value of byte is -127 to 128
	        System.out.println(y);
	        
	        double z=34343.998776d;
	        System.out.println(z);
	        
	         char grade='A';    
	        System.out.println(grade);
	        
	        //method
            //   String h='yash';
            
	        
	}
}



