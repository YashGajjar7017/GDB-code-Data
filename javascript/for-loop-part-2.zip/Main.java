
public class Main
{
	public static void main(String[] args) {
// 		System.out.println("Hello World");
         
         int []a= {1,2,3,4,5};
         int i;
         
        //  classical way
         for(i=0;i<a.length;i++)
         {
             System.out.println(a[i]);
         }
         
        //  for else
        
        for(int value:a){
            System.out.println(value);
        }
        
	}
}
