
public class Main
{
	public static void main(String[] args) {
		System.out.println("My name is yash");
		
		/*operators in java:
		   1)Operand
		   2)operators
		   
		   Operand operators Operand  =  result
		     4       +          10     =  14 
		     
		    -----------------------------------
		     TYPES OF OPERATORS IN JAVA:
		     1)Arithmetic operators
		     2)Assigment operators
		     3)Logical operators
		     4)Comparsion operators
		   -----------------------------------  
		 */
		 
		 
		 //Arthmetic operators
		 int num1=1080,a=1080,b=1080,c=1080;
		 float num2=40;
		 System.out.println("your answer is :" );
		 System.out.println(num1+num2);
		
		 System.out.println("your answer is :" );
		 System.out.println(num1-num2);
		 
		 System.out.println("your answer is :" );
		 System.out.println(num1%num2);
		 
		 System.out.println("your answer is :" );
		 System.out.println(num1*num2);
		 
		 System.out.print("your answer is :" );
		 System.out.println(num1 / num2);
		                                 
		// If you remove ln from print then your answer is print in same line 
		
	    //* increnment and decrement operators:
		    
			 System.out.println(num1++);
		  	 System.out.println(++a);
		  	 System.out.println(b--);
			 System.out.println(--c);
	    
	    a+=20;
	    System.out.println(a);
		
		b-=4;
		System.out.println(b);
		
// 		find this *= , /= ,%=;
		
		
		
		
		
		
		
		
		
		
	}   
}
