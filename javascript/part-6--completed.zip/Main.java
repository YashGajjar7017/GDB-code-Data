public class Main{
    public static void main ( String [] args){
        System.out.println("My name is yash");
        
        System.out.println("Question: Write a program to calculate percentage of a given students in CBSE board exam");
        System.out.println("   His marks from 5 subjects must be taken as input from keyboard (marks are out of 100)");
    }
}