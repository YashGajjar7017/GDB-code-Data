
public class Main
{
    
    static int sum(int a,int b){
        return a+b;
        
         System.out.println(sum(a:5,b:7);
    }
    //  System.out.println(sum(a:5,b:7);
    
    public static void main(String[] args) {
// 		System.out.println("Hello World");

     




	}
}
