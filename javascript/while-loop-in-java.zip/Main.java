
public class Main
{
	public static void main(String[] args) {
// 		System.out.println("Hello World");
         int a=0,b=0;
         
         while(a<100)
         {
             System.out.println(a);
             a+=1;
         }
         
         //do while
         System.out.println("========================");
         do{
             System.out.println(b);
             b+=1;
         }while(b<100);

      



	}
}
