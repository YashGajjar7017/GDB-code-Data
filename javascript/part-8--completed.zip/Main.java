public class Main{
    public static void main (String[] args) {
        System.out.println("my name is yash");
        
        //  there are five types of operater :
        //  1)Assigment operater 
        //  2)Arthmic operater 
        //  3)comperasio operater
        //  4)logical operater 
        //  5)bitwise operater
        
       int a=10;
       int b=a+10;
       System.out.println(b);
      
    //   int b=a-10;
    //   System.out.println(b);
      
    //   int b=a*10;
    //   System.out.println(b);
      
    //   int b=a/10;
    //   System.out.println(b);
    
    int c=24;
    int d=6;
    System.out.println(24>6&&6<24);
      
        
        
        
        
        
        
        
        
        
    }
}
