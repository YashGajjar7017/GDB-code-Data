
public class Main
{
	public static void main(String[] args) {
// 		System.out.println("Hello World");
		
		int [][]matrix ={{2,0,9} ,{3,4,5}};
		System.out.println(matrix [1][1]);
		
		
		String []yash={yash merseses,susuke,yake,suke,kaiyan,koisenorgee};
		
		
		
		
		
	}
}
