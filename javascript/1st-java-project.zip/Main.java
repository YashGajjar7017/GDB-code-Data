
public class Main
{
	public static void main(String[] args) 
	{
		System.out.println("my name is yash");
	


// public static void main(String[] args)
    
     System.out.println("----------------");   
        
    }    
}
//time: 25.20














// time:15:53