
  class helloworld
  import java.util.Scanner;
{
	public static void main(String[] args) {
		System.out.println("Your result");
		
// ====================================
//       question 1
//         float sub1 = 34;
//         float sub2 = 56;
//         float sub3 = 92;
		
// 		float cgpa = (sub1+ sub2 + sub3)/30;
// 		System.out.println(cgpa);


// =========================================		
// 		question 2
// 	import java.util.Scanner;
//     class HelloWorld {
//     public static void main(String[] args) {
//          System.out.println("Hello, World!");
//         	System.out.println("What is your name?");
// 		Scanner sc= new Scanner(System.in);
// 		String name =sc.next();
// 		System.out.println("hello!" +name+ " have a good day");
//     }
// }










	}
}


