#include <iostream>

using namespace std;
int a=10;
int main()
{
int a,b,ans;
a=5;
cout << ::a; // scope resolution operator access global operator
return 0;
}

