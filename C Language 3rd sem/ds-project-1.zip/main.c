#include<stdio.h>
#include<conio.h>
#include<string.h>
struct emp
{
  char emp_name[20];
  int emp_id;
  char emp_dept[20];
  float emp_salary;
};
int
main ()
{
  int i;
  struct emp e[3];		//variable
//struct emp *e; //pointer
//e=&e1; //point to variable
  for (i = 0; i < 3; i++)
    {
      printf ("Enter employee name\n");
      scanf ("%s", e[i].emp_name);
      printf ("Enter employee id\n");
      scanf ("%d", &e[i].emp_id);
      printf ("Enter employee department\n");
      scanf ("%s", e[i].emp_dept);
      printf ("Enter employee salary\n");
      scanf ("%f", &e[i].emp_salary);
      printf ("\n\n");
    }
  printf ("Employee details\n");
  printf ("*****************\n\n");
  for (i = 0; i < 3; i++)
    {

      printf
	("\nEmployee name=%s\nEmployee Id=%d\nEmployee Department=%s\nEmployee salary=%f\n",
	 e[i].emp_name, e[i].emp_id, e[i].emp_dept, e[i].emp_salary);
    }
  return 0;
}
