#include<iostream>
using namespace std;
class complex
  {
      private:
         float x;
         float y;
      public:
         void getdata (float real,float imag)
         {
             x=real;
             y=imag;
         }
    friend complex sum(complex ,complex);
    void show(complex);
    
  };
  
  complex sum(complex c1,complex c2)
  {
      complex c3;
      c3.x=c1.x+c2.y;
      c3.y=c1.y+c2.y;
      return (c3);
  };
   void complex :: show (complex c)
   {
       cout<< c.x<<"+j" << c.y<<endl;
       
   }
   int main()
   {
       complex A,B,C;
       A.getdata(3.1,5.65);
       B.getdata(2.75,1.2);
       C=sum(A,B);
       cout<<"A";
       A.show(A);
       cout<<"B=";
       B.show(B);
       cout<<"C=";
       C.show(C);
       return 0;
       
   }
  
  
  
  
  
  
  
  
  