int main()
{
int a,b,ans;
a=5;
b=10;
ans = a & b;
cout << ans << endl;
ans = a | b;
cout << ans << endl;
ans = a ^ b;
cout << ans << endl;

ans = ~a;
cout << ans << endl;
ans=~b;
cout << ans;

return 0;
}