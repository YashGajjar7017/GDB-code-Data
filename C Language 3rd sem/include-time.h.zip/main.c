#include <stdio.h>
#include <time.h>

int m[9999][999];
intmain ()
{
   int i, j;
   clock_t start, stop;
   double d = 0.0;
   start = clock ();
   
   //row-major
  for (i = 0; i < 9999; i++)	//row
    {
      for (j = 0; j < 999; j++)	//column
	  {
	     m[i][j] = m[i][j] + (m[i][j] * m[i][j]);
	  }
    }
    
    stop = clock ();
    d = (double) (stop - start) / CLOCKS_PER_SEC;
    printf ("The run-time of row major order is %lf\n", d);
    start = clock ();
    // ----------------------------
    
//column major
    for (j = 0; j < 999; j++)	//column
       {
        for (i = 0; i < 9999; i++)	//row
	       {
	         m[i][j] = m[i][j] + (m[i][j] * m[i][j]);
	       }
        }
        
  stop = clock ();
  d = (double) (stop - start) / CLOCKS_PER_SEC;
  printf ("The run-time of column major order is %lf", d);
  return 0;
}
