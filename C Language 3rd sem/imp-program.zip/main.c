#include <iostream>
#include <iomanip>



using namespace std;



int main()
{
float f=0.1234;
int a=6789;
cout << setw(10);
cout <<setfill('#');
cout << a << endl;
cout << setprecision(3);
cout << f;
return 0;
}

