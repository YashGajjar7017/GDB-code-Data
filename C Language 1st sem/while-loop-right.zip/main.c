#include<stdio.h>
void main()
{
    int a,b;
    
    printf("Enter first number:\n");
    scanf("%d",&a);
    
    printf("Enter second number:\n");
    scanf("%d",&b);
    
    while(a=b)
    {
        printf("true\n");
    }
}
