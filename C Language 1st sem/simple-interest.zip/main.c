#include<stdio.h>
void main()
{
    int p,n,count;
    float r,si;
    
    count=1;
    while(count<=3)
        {
            printf("Enter the values of per,n and rate:\n");
            scanf("%d\n %d\n %f",&p,&n,&r);
            si=p*n*r/100;
            printf("simple interest->RS.%f",si);
            
            count=si+1;
            
        }
}