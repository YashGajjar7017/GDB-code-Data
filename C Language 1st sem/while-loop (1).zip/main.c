#include<stdio.h>

int main()
{
    int a,b;
    printf("Enter your first number :\n");
    scanf("%d",&a);
    
    printf("Enter your second number :\n");
    scanf("%d",&b);
    
    while(a>b)
       {
           printf("true");
       }
    
       {
            printf("false");  
       }
       
}
