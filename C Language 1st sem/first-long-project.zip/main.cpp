/*How to do shopping onine with this program 
proceesing shopping list */

#include<iostream>
#include<stdio.h>

using namespace std;

const m=50;

class ITEMS

{
    int itemcode[m];
    float itemprice[m];
    int count;
    
    public:
    void cnt(void)(count =0;}
    void getitem(void);
    void displaysum(void);
    void remove(void);
    void displayitems(void);
};
//+++++++++++++++++++++++++++++++++++++++
printf("+++++++++++++++++++++++++++++++++");

void ITEMS::getitem(void);
{
    cout <<"Enter item code:";
    cin>>itemcode[count];
    
    cout <<"Enter your cost :";
    cin>>itemprice[count];
    count++;
} 
void ITEMS::displaysum(void)

{
   float sum=0;
   for(int i=0;i<count;i++)
     sum=sum+itemprice[i];
     
     count<<"\ntotal value :"<<sum<<"\n";
}
void ITEMS::remove(void)
{
    int a;
    cout<<"Enter item code:";
    cin>>a;
    
    for(int i=0;i<count; i++);
        if(itemscode[i]==a)
           itemsprice[i]=0;
           
}
void main::displayitems(void)
{
    count<<"\ncode price\n";
    
    for(int i=0;i<count;i++)
    {
        cout<<"\n << itemscode[i]";
        cout<<"    "<<itemprice[i];
    }
    cout<<"\n";
}
//++++++++++++++++++++++++++++++++++++++++++++++++

int main ()
{
    ITEMS order;
    order.cnt();
    int x;
    do
    {
        cout<<"\nyou can do the following;"
            <<"Enter approprite number \n";
        cout<<"\n1 :Add an item";
        cout<<"\n2 :display total value";
        cout<<"\n3 :delete an item";
        cout<<"\n4 :dipaly all items";
        cout<<"\n5 :Quit";
        cout<<"\n\n what is your option??";
        
        cin>>x;
        
        switch(x)
        {
            case 1:order.getitem(); break;
            case 2:order.displaysum(); break;
            case 3:order.remove();break;
            case 4:order.displayitems();break;
            case 5:cout<<"Error in input;try again\n";
        }
    } while(x!=5);
    
    return 0;
}
        
            
            
            
            
    
         
         
         
         
         
         
         

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

           
    
    
    
    
    
    
    
    
    

     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
   
   
   
   
   
    















