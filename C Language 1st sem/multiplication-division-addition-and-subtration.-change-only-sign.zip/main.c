#include<stdio.h>

void main()
{
    int a;
    int b;
   
    printf("\nEnter your first number :");
    scanf("%d",&a);
    
    printf("\nEnter your second number :");
    scanf("%d",&b);
    
    int multiply=a>b; /*change the sign only*/
    printf("\n your answer is :%d",multiply);
    
}
