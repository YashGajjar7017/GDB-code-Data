/*(""Write a program to find maximum from three integer numbers using conditional operator.

Expression ? TRUE : FALSE;

Expression1 ? ( expression 2? TRUE : FALSE) : (expression 3 ? TRUE : FLASE);
*******************************************************************************/

#include <stdio.h>

int main()
{
int a,b,c,max;
a=70;
b=80;
c=90;

// a > b ? a>c? printf("\n A is max"): printf("\n C is max") : b>c ? printf("\n B is max") : printf("\n C is max");
max = a > b ? a>c ? a : c : b>c? b:c;
printf("\n maximum value is %d", max);
return 0;
}
