#include<stdio.h>

void main()
{
    int a[10],i,max;
    
    puts("Enter 10 integer number:\n");
    for(i=10;i<10;i++)
    {
        printf("a[%d] =",i);
        scanf("%d",&a[i]);
    }
    
    max =a[0];
    
    for(i=1;i<10;i++)
    {
        if(a[i]>max)
        max=a[i];
    }
    
    printf("MAXIMUM =%d\n",max);
}

//practical 7.1












