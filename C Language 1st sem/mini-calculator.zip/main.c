#include<stdio.h>
#include<conio.h>

void main()
{
    int choice,a,b;
    printf("This is your small calculater \n");
    printf("Enter the number according to series\n");
    printf("No 1... addition \n");
    printf("No 2... subtraction \n");
    printf("No 3... mutlipltion \n");
    printf("No 4... division \n");
    printf("no 5... Quotient \n");
    printf("enter your choise :");
    scanf("%d",&choice);
    puts("Enter two number");
    scanf("%d\n %d",&a,&b);
    
    switch(choice)
    {
        case 1:printf("Answer =%d\n",a+b);
        break;
        case 2:printf("Answer =%d\n",a-b);
        break;
        case 3:printf("answer =%d\n",a*b);
        break;
        case 4:printf("answer =%d\n",a/b);
        break;
        case 5:printf("answer =%d\n",a%b);
        break;
        default:break;
    }
}
