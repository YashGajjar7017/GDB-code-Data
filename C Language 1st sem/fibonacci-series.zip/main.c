/*Fibonacci series*/


#include<stdio.h>

void main()
{
    int term =147,i,t1=0,t2=1,sum ;
    
    for(i=1;i<=term;i++)
    {
        printf("%d \t",t1);
        sum =t1+t2;
        t1=t2;
        t2=sum;
    }
}
