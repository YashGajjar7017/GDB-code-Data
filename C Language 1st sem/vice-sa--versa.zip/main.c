#include <stdio.h>

int main()
{
    char a,b,c,t;
    printf("\n Enter first character: ");
    scanf("%d",&a);
    t=getchar();
    printf("\n Enter Second character :");
    scanf("%d",&b);

    c=a; 
    a=b;
    b=c;
    printf("\n a=%d b=%d ", a,b);

    return 0;
}