/******************************************************************************
Write a program to print following series
3 6 9 12 15 .....
*******************************************************************************/

#include <stdio.h>

int main()
{
    
    int i,n;
    printf("\n Enter the value of n : ");
    scanf("%d",&n);
    printf("\n Loop begins");
    for(i=3; i<=n; i=i+3)
    {
    printf("\t %d ",i);
    }
    printf("\n Loop is end");

}