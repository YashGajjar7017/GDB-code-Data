#include<stdio.h>
#include<conio.h>

void main()
{
    int a[5]={23,54,67,5,2};
    //a[]={1};
    //scanf("%d",&a[3]);
    printf("your answer is :%d",a[4]);
    
}



