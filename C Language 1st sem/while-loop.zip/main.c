#include<stdio.h>
#include<conio.h>

int main()
{
    int num=1;
    while(num<=10)
    {
        printf("%d\n",num);
        num++;
    }
}