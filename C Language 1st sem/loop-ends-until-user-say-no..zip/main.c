#include<stdio.h>
#include<conio.h>
void main()
{
    char c= 'y';
    int num;
    
    while(c== 'y')
    {
        printf(" Enter an interger : ");
        scanf("%d",&num);
        getchar();
        printf(" you have entered %d\n",num);
        printf(" do you want to continue(y/n)?:" );
         c= getchar();
        
    }
    
}
