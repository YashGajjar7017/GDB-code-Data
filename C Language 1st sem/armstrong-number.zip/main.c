/******************************************************************************
Write a program to check given number number is armstrong or not
madam
123 = 1^3 + 2^3 + 3^3
153 = 1^3+ 5^3 + 3^3 = 1+ 125+ 27 = 153
*******************************************************************************/
#include <stdio.h>
int main()
{
    int no1,original, d,sum=0;
    printf("\n Enter any integer number :");
    scanf("%d",&no1);
    original=no1;
    while(no1>0)
    {
    d= no1%10;
    no1 = no1 /10;
    sum = sum + d*d*d;
    }
    if(original==sum)
    {
    printf("\n The number %d is a armstrong", original);
    }
    else
    {
    printf("\n The number %d is not a armstrong number",original);
    }
 /* 123 === 321 */
}