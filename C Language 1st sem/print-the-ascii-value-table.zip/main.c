#include <stdio.h>
void main()
{
    char i;
    for(i='A';i<='Z';i++)
    printf("\nASCII of %c is \n%d",i,i);
    
}
