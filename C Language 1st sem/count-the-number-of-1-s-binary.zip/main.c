#include <stdio.h>

void main()
{
  unsigned int x;
  int cnt=0;
  int i;
  
  printf("Enter an unsigned interger \n");
  scanf("%u",&x);
  
  
  for(i=0;i<16;i++)
     {
        if (x & 1)
        cnt++;
        x = x >> 1;
     }
   printf("number of 1\'s : %d \n",cnt);
}
        
      
  
  
  
  
  
  

