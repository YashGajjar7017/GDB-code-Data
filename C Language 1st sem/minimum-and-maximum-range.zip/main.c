#include<stdio.h>
void main()
{
    int min,max,oddnum,sum=0;
    
    puts("Enter minimum and maximum of a range");
    scanf("%d %d",&min,&max);
    
    if((min % 2)==1)
     {
         oddnum = min;
     }
     else
     {
         oddnum = min+1;
     }
    while (oddnum <= max)
      {
          sum+= oddnum;
          oddnum+= 2;
      }
    printf("sum is :%d\n",sum);
}    
    
    
    
    
   
