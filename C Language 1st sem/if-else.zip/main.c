#include<stdio.h>

 void main()
{
   int a,b,t;
   
    
    if(10!=9)
      {
          printf("true");
      }
    else
     {
         printf("false");
     }
     //printf("your answer is :%d",y);
    
}