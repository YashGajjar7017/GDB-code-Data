#include<stdio.h>
#include<conio.h>
// #define b=5
void main()
{
    int a,b,c;

    printf("Enter your number \n");
    scanf("%d",&a);
    
    printf("Enter second number \n");
    scanf("%d",&b);
    
    printf("Enter third number \n");
    scanf("%d",&c);
    
    
    
    if(a<15 || b<15 && c<15)
    {
        printf("true");
    }
    else
    {
        printf("false");
    }
      
}