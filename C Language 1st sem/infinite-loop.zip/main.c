 #include <stdio.h>
    void main()
    {
        int i = 0;
        while (++i)
        {
            printf("");
        }
    }