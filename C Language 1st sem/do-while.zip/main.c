#include<stdio.h>
#include<conio.h>
void main()
{
   int i=110;
   do{
       printf("%d",i);
       i--;
   }while(i>110);
}

