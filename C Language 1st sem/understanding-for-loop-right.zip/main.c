#include<stdio.h>
void main()
{
    int b,a;
    printf("Enter your number:\n");
    for(a=4;a<120;a++)
    {
        printf("%d\n",a);
    }
    printf("==================");
    for(b=0;b<50;b++)
    {
        printf("\n%d\t",b);
    }
}