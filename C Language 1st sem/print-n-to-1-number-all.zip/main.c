#include <stdio.h>
int main()
{
    int a;
    puts("\n Enter any integer number:");
    scanf("%d",&a);
    while(a>0)
    {
    printf("\t %d", a);
    a--;
    }
}