/******************************************************************************
// Write a program to check number is prime or not
*******************************************************************************/

#include <stdio.h>
int main()
{
    int no,cnt =2,prime=1;
    puts("\n Enter the an integer number");
    scanf("%d",&no);
    while(cnt < no)
    {
    if(no%cnt == 0)
    {
    prime =0;
    break;
    }
    printf("\n %d",cnt);
    cnt++;
    }
    if(prime==1)
    printf("\n Number is prime");
    else
    printf("\n Number is not prime");
}