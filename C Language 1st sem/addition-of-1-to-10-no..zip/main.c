#include<stdio.h>


void main()
{
    int i;
    int sum =0;
    
    i=1;
    while(i <=10)
    {
        sum+=i;
        i+=1;
    }
    printf("sum =%d\n",sum);
}