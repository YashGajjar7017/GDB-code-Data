/******************************************************************************
Write a program to print all odd numbers within 1 to n numbers
1 3 5 7 9
*******************************************************************************/

#include <stdio.h>
int main()
{

    int i,n;
    printf("\n Enter the value of n : ");
    scanf("%d",&n);
    printf(" your Loop begins:\n");
    for(i=1; i<=n; i=i+2)
    {
    printf("\t %d ",i);
    }
    printf("\n your program is finished");

}