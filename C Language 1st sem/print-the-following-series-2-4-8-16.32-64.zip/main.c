/******************************************************************************
Write a program to print following series
2 4 8 16 32 64 ...
Complete this program
*******************************************************************************/

#include <stdio.h>
int main()
{

    int i,n;
    printf("Enter the value of n :\n");
    scanf("%d",&n);
    printf("\n Loop begins");
    for(i=2; i<=n; i=i*2)
    {
    printf("\n %d ",i);
    }
    printf("\n Loop is end");

}
