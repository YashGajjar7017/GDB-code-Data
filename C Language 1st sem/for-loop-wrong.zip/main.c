#include<stdio.h>
void main()
{
    int a[20],b,c;
    
    printf("Enter the number linewise:\n");
    for(b=0;b<=10;b++)
    {
       scanf("%f",a[20]);
    }
    
    for(c=1;c<=10;c++)
    {
        printf("%d",a[20]);
    }
}