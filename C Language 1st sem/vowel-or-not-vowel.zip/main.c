/******************************************************************************
Write a program to check entered character is vowel or not
*******************************************************************************/
#include <stdlib.h>
#include <stdio.h>

int main()
{
    char ch;
    scanf("%C",&A)
    ch='A';
    switch(ch)
   {
   case 'A':
   case 'a':
   case 'E':
   case 'e':
   case 'i':
   case 'I':
   case 'O':
   case 'o':
   case 'u':
   case 'U':
   printf("\n The given character is a vowel:");
   break;
   defult:
   printf("\n The given character is not a vowel");
   }
   getchar();
}



