#include<stdio.h>
#include<conio.h>

void main()
{
    int a,b,c,d;
    printf("your first number:a++\n"); 
    scanf("%d",&a);
    printf("your second number :a--\n");
    scanf("%d",&b);
    printf("you third number :++a\n");
    scanf("%d",&c);
    printf("your fourth number:--a\n");
    scanf("%d",&d);
    a++,b--,++c,--d;
    
    printf("your answer is :%d,%d,%d,%d",a++,b--,++c,--d);
  
    
}

