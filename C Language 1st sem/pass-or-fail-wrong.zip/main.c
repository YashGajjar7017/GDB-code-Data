#include<stdio.h>
#include<conio.h>

enum index {FAIL,PASS};

void main()
{
    int marks[20],i;
    int group[4]={0,0,0,0};
    
    printf("Enter the students marks one by one :\n");
    for(i=0;i<4;++i)
       {
           scanf("%d\n",&marks[i]);
       }
       
    for(i=0;i<4;i++)
       {
           if(marks[i] <14)
           group[FAIL]++;
    else if(marks[i] <40)
          group[PASS]++;
    
       }
    
    printf("FAIL=%d PASS =%d ",group[FAIL],group[PASS]);
        
            
    
}
