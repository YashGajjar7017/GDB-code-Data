/******************************************************************************
Write a program to print print 1 to n number times
*******************************************************************************/

#include <stdio.h>
int main()
{

    int i,n;
    printf("\n Enter the value of n : ");
    scanf("%d",&n);
    printf("\n Loop begins");
    for(i=1; i<=n; i=i+1)
    {
    printf("\n %d ",i);
    }
    printf("\n Loop is end");

}