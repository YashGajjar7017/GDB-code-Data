#include<stdio.h>
#include<conio.h>
void main()
{
    int a=13,b=2;
    a++, b--;
 
    printf("your first anwer :%d\n your second ans :%d",a++,b--);
    //  printf("your ans :%d",b--);
}