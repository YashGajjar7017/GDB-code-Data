#include<stdio.h>
void main()
{
    int i,n;
    puts("\nEnter a number");
    scanf("%d",&n);
    
    printf("table ->\n");
    for(i=1;i<=20;i++)
    {
        printf("%4d x %2d =%4d\n",n,i,n*i);
    }
}
//program 6.11; page 143;







