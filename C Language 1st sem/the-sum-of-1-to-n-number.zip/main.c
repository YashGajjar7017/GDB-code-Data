#include<stdio.h>
#include<conio.h>
void main()
{
    int i= 1,sum =0,n;
    
    puts("Enter value of N");
    scanf("%d",&n);
    
    next :
         sum= sum+i;
         i+=1;
         if (i<=n)
         goto next;
         
    printf("sum = %d\n",sum);
}