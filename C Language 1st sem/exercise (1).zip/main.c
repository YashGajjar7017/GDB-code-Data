#include<stdio.h>
main()
{
    int a,b;
    printf("Enter the first value :");
    scanf("%d",&a);
    
    printf("Enter your second value:");
    scanf("%d",&b);
    
    while(a>b)
      {
        printf("true");
      }
      {
        printf("FALSE");
      }
}