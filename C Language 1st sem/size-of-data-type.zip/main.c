/******************************************************************************

sizeof -> size of the data type

*******************************************************************************/

#include <stdio.h>
#include<conio.h>

int main()
{
int a;
char c;
float f;
long double d;
double d1;
long int ld;
short int sd;

printf("\n size of integer is %d", sizeof(int));
printf("\n size of integer is %d", sizeof(char));
}