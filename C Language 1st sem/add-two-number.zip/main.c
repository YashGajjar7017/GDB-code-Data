#include <stdio.h>
#include <conio.h>
void main()
{
    int a;
    int b;
    int result=a+b;
    
    printf("Enter your first number \n");
    scanf("%d",&a);
    
    printf("Enter your second number \n");
    scanf("%d",&b);
    
    printf("your answer is :",result);
}