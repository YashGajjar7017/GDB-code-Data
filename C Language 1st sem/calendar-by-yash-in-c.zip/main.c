#include<stdio.h>
#include<stdlib.h>

int main()
{
    //system("color 3f");
    int year,month,day,dayInMonth,weekday=0,startingDay;
    
    printf("\n Enter your desired year:");
    scanf("%d",&year);
    
    char *months[]={"january","february","march","April","may","June","july","august","septerber","octabar","november","decmeber"} ;
    int monthDay[]={31,28,31,30,31,30,31,31,30,31,30,31};
    
    if((year%4==0&&year%100!=0)||year%400==0)
     monthDay[1]=29;
    
    for(month=0;month<12;month++)
      {
          dayInMonth=monthDay[month];
          printf("\n\n--------------------%s--------------------\n",months[month]);
          printf("\n   sun mon tue wed thru fri sat \n");
          
          for(day=1;day<=dayInMonth;day++)
          {
              printf("%5d",day);
              
              if(++weekday>6)
              {
                  printf("\n");
                  weekday=0;
              }
              startingDay=weekday;
              
              
              
          }
          
          
          
          
          
          
          
      }
}











