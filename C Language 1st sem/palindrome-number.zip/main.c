/******************************************************************************
Write a program to check given number number is palindrome or not
madam
121
123
*******************************************************************************/
#include <stdio.h>

int main()
{
    int no1,original, d,rev=0;
    printf("\n Enter any integer number :");
    scanf("%d",&no1);
    original=no1;
    while(no1>0)
    {
    d= no1%10;
    no1 = no1 /10;
    rev = rev*10 + d;
    }
    if(original==rev)
    {
    printf("\n The number %d is palindrome", rev);
    }
    else
    {
    printf("\n The number %d is not palindrome",rev);
    }

}
