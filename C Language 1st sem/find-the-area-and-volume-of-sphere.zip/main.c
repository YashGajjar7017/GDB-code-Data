#include <stdio.h>
#include <conio.h>

void main()
{
    float radius,volume,area;
    
    printf("Enter the radius of sphere \n");
    scanf("%f",&radius);
    
    /*compose area and volume*/
    area =4*3.14*radius;
    
    volume =(4*3.14*radius*radius*radius)/3;
    
    printf("area +%f volume =%f\n",area,volume);
    
    
    
    
    
    
    
    
}