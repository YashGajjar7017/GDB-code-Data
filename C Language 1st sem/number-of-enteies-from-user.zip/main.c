/******************************************************************************
Write a program to add all the numbers enter by the user. Stop the program if user enters 0
*******************************************************************************/

#include <stdio.h>

int main()
{
    int no, sum=0;
    do
    {
    puts(" \nEnter the an integer number (enter 0 to stop) :");
    scanf("%d",&no);
    sum = sum + no;
    }
    while(no!=0);
    printf("Total of all entered no = %d",sum);
    
    
}