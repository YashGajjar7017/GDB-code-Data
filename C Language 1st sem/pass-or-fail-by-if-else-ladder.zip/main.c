#include<stdio.h>
#include<conio.h>

enum index {FAIL,PASS,FIRST_CLASS,DISTICTION};

void main()
{
    int marks[20],i;
    int group[4]={0,0,0,0};
    
    puts("Enter the marks of 20 students");
    for(i=0;i<5;i++)
       {
           scanf("%d\n",&marks[i]);
       }
       
    for(i=0;i<5;i++)
       {
           if(marks[i] <14)
           group[FAIL]++;
    else if(marks[i] <40)
          group[PASS]++;
    else if(marks[i] <70)
          group[FIRST_CLASS]++;
    else
          group[DISTICTION]++;
           
       }
    
    printf("FAIL=%d PASS =%d FIRST_CLASS=%d DISTICTION=%d",group[FAIL],group[PASS],group[FIRST_CLASS]);
        printf(group[DISTICTION]);
            
    
    
}