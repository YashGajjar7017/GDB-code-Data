#include <stdio.h>
void main()

{
    int num;
    
    printf("Enter your number \n");
    scanf("%d",&num);
    
    if(num % 2==1)
      {
          printf("number is odd \n");
      }
    else
     {
         printf("number is even \n");
     }
}