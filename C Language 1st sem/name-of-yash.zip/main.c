#include <stdio.h>
#include <conio.h>

void main ()
{
    printf("#      #    #      ######  #     #\n");
    printf(" #    #    # #     #       #     #\n");
    printf("  # #     #   #    ######  #######\n");
    printf("   #     #######        #  #     #\n");
    printf("   #    #       #  ######  #     #\n");
}