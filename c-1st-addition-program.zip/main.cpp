#include<iostream>
using namespace std;

int main()
{
    float number1,number2,sum,average;
    cout<<"Enter two number: ";
    cin>>number1;
    cin>>number2;
    
    sum = number2+number1;
    average = sum/2;
    
    cout<<"sum = "<<sum<<"\n";
    cout<<"average = "<<average<<endl;
    
    return 0;
    
}