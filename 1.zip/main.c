#include<stdio.h>
void main()
{
    int a;
    int *p,*p1;
    
    p=&a;
    p1=&a;
    a=5;
    
    // printf("the value of a is =%d\n",a);
    // printf("the address of is a =%u\n",&a);
    
    // printf("the content of a pointer p is=%u\n",p);
    // printf("the address of a pointer p is=%u\n",&p);
    
    // *p=10;
    
    // printf("the content of a is =%u\n",*p);
    // printf("the value of a is =%d\n",a);
    
    // (*p)++;
    
    // printf("the value of a is =%d\n",a);
    printf("the address of a pointer is =%u\n %u\n",p,p1);
    printf("%u",&p1);
}