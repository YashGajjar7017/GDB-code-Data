import os #file name 

a =23
b =45.89
c =True
#c =None
print(a)
print(b)
print(c)

print(type(a))
print(type(b))
print(type(c))












