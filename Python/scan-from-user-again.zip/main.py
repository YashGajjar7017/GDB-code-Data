a = input("Enter your name:")
print(a)
print(type(a))
a=int(a)
print("convert to")
print(type(a))

print("---------------------------")
# get the data from user and find avg of it

b=input("Enter the first number:")
c=input("Enter the second number:")

# now this num is scan in string so now convert to int by doing typecasting
b = int(b)
c = int(c)

avg = (b+c)/2
print("Your ans of b and c is:",avg)
print(type(avg))









