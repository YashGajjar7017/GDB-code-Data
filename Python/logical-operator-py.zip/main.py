#logical operator

a =True
b =False

print("The value of a and b is:",a and b)
print("The value of a or b is:",a or b)
print("The value of a not b is:", not b)









