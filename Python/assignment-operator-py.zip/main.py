#Assignment operater

A = 20
A +=2
print("addation",A)

'''a=20
a+=12
print(a)'''
    
b=25
b-=20
print("subtraction",b)

c=2
c*=12
print("multiply",c)

d=20
d/=2
print("division",d)




