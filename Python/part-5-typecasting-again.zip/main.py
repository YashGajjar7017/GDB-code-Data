# it's string

a="1263"
print(type(a))

# new invention add any number from back!!!!!
print(a+"00")

print("-------------------------")
# typecasting
'''
What is typecasting?
ans: typecasting is way to convert one data type to another data type
'''

b="9999"
print(type(b))

b = int(b)
b+=1

print(type(b))
print(b)





















