#time:2:53:40
#how to sort any series:

print("1)--------------------------------")
a=[2,3.4,1,5,6,3]
a.sort()
print(a)

#--------------------------------

#how to reverse any series:
print("2)--------------------------------")
b=[1,3,5,7,9,11,13]
b.reverse()
print(b)

#--------------------------------

#appends means add anything at last without changing anything 
c=[2,34,54,65,3,56,7,4,3,]
print("3)--------------------------------")
c.append(34)
print(c)

#--------------------------------

#insert means(0 ,40 ) first value is for that value those we change .And second value is for that axis point .
d=[2,4,45,2,3,5,6,72,4]
print("4)--------------------------------")
d.insert(0,20)
print(d)

#--------------------------------

#pop means to delete any num from series
e=[3,5,64,5,12,89,70,56]
print("5)--------------------------------")
e.pop(6)
#e.pop(0,64,5)              {this takes only one arrugument or one index else it gets error} 
print(e)

#--------------------------------

#remove any thing from element
f=[23,45,67,3,5,1,89,33,64,75,322]
print("6)--------------------------------")
f.remove(45)
print(f)















