# operater in python
# Arthmetic operater

a1=20
b1=20
print("the sum of a and b is:",a1+b1)
print("the sum of a and b is:",a1-b1)
print("the sum of a and b is:",a1*b1)
print("the sum of a and b is:",a1/b1)

print("==========================")
# assigment operater

a2=34
a2 -=4
print(a2)

a2 += 6
print(a2)

a2 *=20
print(a2)

a2/=3
print(a2)#if we any int num then your answer is come in float only

print("==========================")
# comparison operater

a=(4<=5)
# a=(4>=5)
# a=(4==5)      
# a=(4>5)
# a=(4<5)
#  a=(4!=5)
print(a)  #Warning:line should be touch on left side .it's compulsary 
 

print("============================")
#  logical operater

b=60
c=40

print("The value of b and c is:",b and c)
print("The value of b or c is:",b or c)
print("The value of b not c is:", not c)








