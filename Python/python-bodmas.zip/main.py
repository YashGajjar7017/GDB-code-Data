#Aritmetic Operater

print("1 addtion :",3+4)
print("2 subtraction :",3-4)
print("3 multiplay :",3*4)
print("4 diision :",3/4)