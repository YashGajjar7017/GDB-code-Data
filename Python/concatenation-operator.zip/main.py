name="good morning,"
greeting="good day,"
print(name+greeting)
print(type(name+greeting))






