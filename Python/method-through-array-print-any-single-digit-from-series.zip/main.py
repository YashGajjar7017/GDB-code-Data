
a="yash"
print(a[3])

b="jaydev"
print(b[2])

#This is same method that print []in this means a ratio of any number.


print(b[1:4])    #this print (jaydev)means (0,1,2,3,4,6) 0=j; and so on.

#this is also called :string sliceing
print(b[-1]) 

