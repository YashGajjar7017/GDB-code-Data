#time:1:36:56

a=34
b=20
print(a+b)

print("@@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@\n")

c=input("Enter your number :")
d=input("Enter your second number")

c=int(c)
d=int(d)
e=c+d
print("Your answer is :",e)
