#time :2:28:48



a= "My name is yash   i am from sciencecity"

doublespace =a.find("   ")
print(doublespace )
#-----------------------------------------------------------------------
a= '''My name is yash . i am from Ahmedabad. 11,sayam villa,b/h satyam complex ,sciencecity road sola, 
Ahmedabad'''


print(len(a))
print(a.find("villa"))
#-----------------------------------------------------------------------
a ="MY NAME IS   YASH ."
a=a.replace("   "," ")
print(a)
#space RELETAD program
#-----------------------------------------------------------------------





















