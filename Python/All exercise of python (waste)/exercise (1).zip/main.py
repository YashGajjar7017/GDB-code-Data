#time: 02:08:45

a= "my name is yash,"
print(type(a))
print(len(a))
print(a.endswith("yash"))
















