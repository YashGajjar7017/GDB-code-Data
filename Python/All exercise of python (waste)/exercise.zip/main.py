
a=40
b=50
print("the sum of this number :",a+b)

c=40
d=4
print("the division of this two number is:",c/d)
print("and your remainder is:",c%d)
















