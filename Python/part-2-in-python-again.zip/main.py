'''

what is variable?
ans: A variable is the name given to a memory location in a program .
      for ex-->a=30 ,b="yash",c=71.22
      
What is keyword?
ans: reversed words in python.

what is identifier?
ans: class, variable names,functons.

how to right string?
ans: '''''',"---",'---'

rules for defining a variable name?
ans: 1)A variable name can contain alphabet,digits and underscore
     2)A variable name can only start with an alphabet and underscore.
     3)A variable name can't start with a digits
     4)No whitespaces is allowed to be used inside a variable name 
     
*variable are the case senstive . 

'''

a=30
b='yash'
c=56.76
d=True
# d=None

# format to print anything 
print (a)
print(b)
print(c)
print(d)

# printing the datatye of variables

print(type(a))
print(type(b))
print(type(c))
print(type(d))
# time:1:03:54





