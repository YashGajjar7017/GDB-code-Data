'''tuple means (,) is an immutable(cannot change) data type in python

a=()means empty tuble;
a=(1,) tuple with only one elements ; this need comma ;
a=(2,56,12)   tuple with more elements'''

t=(45,6,78,22,21,24,26,25,27,45,29,28,20,223,2,)
t1=(1,)
print(t1)

#===================================
print(t.count(2))

#=====================================
print(t.index(45))

#for more tuples if you study then print python.org or python docs





















