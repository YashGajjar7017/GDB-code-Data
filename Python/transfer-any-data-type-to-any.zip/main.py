'''https://youtu.be/gfDE2a7MKjA
time:'''

a="30"
a=int(a)
print(a+5)
print(type(a))

b=465
b=float(b)
print(b-5)
print(type(b))






