'''
Important thing to do before download python 
  1) first to do is Add to path.
  
  2) import thing on complier:
       import os 
       import flask
       import tensoflow
  
  3) install any modules by writting "pip install ---" and hit enter
  
  4) there are two types of modules:
      1) Built in module. ex-os,abc,etc
      2) External module. ex-tensorflow ,flask ,etc
      
  5) "REPL" means "Read Evaluate Print Loop"  
  
  6) To play sound type "pip install playsound "and get the full adress of mp3.
      format: from playsound import playsound
              playsound( address in//with )
  
  7)if we ckeck file in full of module the follow this format:
      --> import os
          print(os.listdir())
  
'''
print ('I am yash')











