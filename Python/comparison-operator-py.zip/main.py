#comparison operater

b =(4>7)
print(b)

b =(4<7)
print(b)

b =(4>=7)
print(b)

b =(4<=7)
print(b)

b =(4==7)
print(b)

b =(4!=7)
print(b)


















