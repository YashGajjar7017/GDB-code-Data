a="My name is yash .Iam from Ahmedabad .I lived at sciencecity ."
print(a)
print(type(a))
#=================================

print("================================")
print("1 addtion :",3+4)
print("2 subtraction :",3-4)
print("3 multiplay :",3*4)
print("4 diision :",3/4)

#=================================
print("================================")
A = 20
A +=2
print("addtion",A)

#=================================
print("================================")
b =(4>7)
print(b)

b =(4<7)
print(b)

b =(4>=7)
print(b)

b =(4<=7)
print(b)

b =(4==7)
print(b)

b =(4!=7)
print(b)

#=====================================
print("====================================")
c =True
d =False

print("The value of a and b is:",c and d)
print("The value of a or b is:",c or d)
print("The value of a not b is:", not d)

#=========================================
print("========================================")

e="30"
e=int(e)
print(e+5)
print(type(e))

#============================================
print("========================================")

g = input("Enter your name :")
print(g)
g=int(g)       #convert a(string) to int
print(type(g))

#===========================================
print("==========================================")

f=input("Enter first number: ")
h=input("Enter second number: ")

f=int(f)
h=int(h)
i=f+h/2
print("The answer is of this solution is :",c)
print(type(i))

#============================================
print("===========================================")

name="good morning,"
greeting="good day,"
print(name+greeting)
print(type(name+greeting))

#=============================================
print("===========================================")

j="yash"
print(a[3])

k="jaydev"
print(b[2])

#This is same method that print []in this means a ratio of any number.


print(b[1:4])    #this print (jaydev)means (0,1,2,3,4,6) 0=j; and so on.

#this is also called :string sliceing
print(b[-1]) 




















