
a=input("Enter first number: ")
b=input("Enter second number: ")

a=int(a)
b=int(b)
c=a+b/2
print("The answer is of this solution is :",c)
print(type(c))