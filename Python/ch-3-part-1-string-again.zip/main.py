#1:39:35

a=input("Enter your name:")
print("Hello " + a + "nice to meet you!")
b=input("how many member are you in family:")
print(b+" ok nice!")
print("your data is ",a,b)
#1:46:54


