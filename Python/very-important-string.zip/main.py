a='''My name is yash. i am lived st sciencecity near sola .sciencecity is very good place .i love this very much
and  lived for last 10 years.'''

print(len(a))
#(len) it is used for count char in a line or sentence

print(type(a))
#(type) is used to see that what line is it. it is str,float,int. 

print(a.endswith("much"))
#(endswith) is used to ckeck that any line is end with with char .

print(a.count("n"))
#(count("")) is used to ckeck that how many number or char are there in a line

print(a.capitalize())
#This make the first letter caplital complurery

print(a.find("10"))
#find that how many thing that we write in this ("") present in sentence

print(a.replace("yash","mahi"))
#repllce is used for replace or change with any thing .

#print(/n,\t ,\ ,\\)
b =input("Enter your name :\n")
print("good morning, "+ b)















