
a = input("Enter your name :")
print(a)
a=int(a)       #convert a(string) to int
print(type(a))


b="56"
print(b)
b=float(b)
print("your answer is:",b)







