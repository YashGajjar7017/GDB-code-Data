#time :

a=[2,4,5,23,56,98]

print("the sum of all this number is:" )
print(a[1],a[2],a[3],a[4],a[5],a[0])
print(sum(a))























