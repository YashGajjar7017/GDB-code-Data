# This is shows how to make a dictionaries using python.

dict = {
    "1)yash":"1)It is name of boy.",
    
    "2)car":'''2)a four-wheeled road vehicle that is powered by an engine and is able to carry a 
    small number of people.''',
    
    "3)encyclopedia":'''3)An encyclopedia or encyclopaedia (British English) is a reference 
    work or compendium providing summaries of knowledge either from all branches or from 
    a particular field or discipline. ... Encyclopedia entries are longer and more detailed than those 
    in most dictionaries.  ''',
    
    "4)marks":"4)[23,45,67,87,75,63,36]",
    }

print(dict["1)yash"])    
print(dict["2)car"])
print(dict["3)encyclopedia"])
print(dict["4)marks"])

#============================================================

'''Property of a python dictionaries:
1)It is a unorder .
2)It is mutable.
3)It is indexed
4)Cannot contain duplicate keys.'''
#=============================================================

print("======================================================")

"Function of python dictionaries:"

print(dict.keys())
print(type(mydict.keys()))

 #time:3:30:13   
    
    
    
    
    
    



