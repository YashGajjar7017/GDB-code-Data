#time:

a="yash is good boy"
print(a[0:9:1])  #last digit is for skip any charecter

#string function

yash="once upon time i go to zoo and play with animals .i got a lot of fun with animals,jjijiji"
print(yash[0::])
print(len(yash))   #len value shows ,how many number are there in sentence without human counting.












