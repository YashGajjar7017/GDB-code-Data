a=''' Dear <|name|> 
    greeting from my indian family,
    I am very happy to tell you that you are winner of this
    competition, congratulation,your gift is going on and you 
    get i two to three days ,
    
    best wishes from me;
    your yash 
    
    date:<|date|>'''
    
name=input("Enter your name :")
date=input("now enter your date :")
a=a.replace("<|name|>",name)
a=a.replace("<|date|>",date)
b=input("Enter your seruity code:")
print(a)

















