#include<stdio.h>
int main()
{
    int *p,a;
    p=&a;
    // scanf("%d",&a);
    a=14;
    
    printf("\n The value of a is=%d",a);
    printf("\n The address of a is=%u",&a);
    printf("\n The pointer value is=%u",p);
    printf("\n The address of pointer is=%d",&p);
    printf("\n The indirect value of a using pointer *p=%d",*p);
    return 0;
}